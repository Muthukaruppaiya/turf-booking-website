package com.postgre.exdemopost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExdemopostApplicationTests {

	@Test
	void contextLoads() {
	}

}
