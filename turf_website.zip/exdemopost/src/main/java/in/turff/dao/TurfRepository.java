package in.turff.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.turff.model.Turf;

public interface TurfRepository extends JpaRepository<Turf, Long> {
    
    List<Turf> findAll();
}