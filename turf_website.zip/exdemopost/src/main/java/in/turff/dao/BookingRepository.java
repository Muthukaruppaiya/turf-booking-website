package in.turff.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.turff.model.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByTurfId(Long turfId);
    List<Booking> findByTurfIdAndBookingDate(Long turfId, LocalDate bookingDate);
    List<Booking> findAll();
    List<Booking> findByTurfIdAndBookingDateAndBookingTime(Long turfId, LocalDate bookingDate, LocalTime bookingTime);
	List<Booking> findByUserName(String username);
	

}

