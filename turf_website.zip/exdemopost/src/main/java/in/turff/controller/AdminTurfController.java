package in.turff.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.turff.model.Booking;
import in.turff.service.TurfService;

@Controller
public class AdminTurfController {
    
    @Autowired
    private TurfService turfService;
    
//    @GetMapping("/home")
//    public String showHome(Model model) {
//        // Add any model attributes if needed
//        return "index";
//    }
//    
    

    @GetMapping("/bookings/{turfId}")
    public String getBookingsForTurf(@PathVariable Long turfId, @RequestParam LocalDate bookingDate, Model model) {
        List<Booking> bookings = turfService.getBookingsForTurfOnDate(turfId, bookingDate);
        model.addAttribute("bookings", bookings);
        return "bookings"; // Assuming there's a bookings.html template to display the bookings
    }

    @GetMapping("/admin/dashboard")
    public String showAdminDashboard(Model model) {
        List<Booking> bookings = turfService.getAllBookings();
        model.addAttribute("bookings", bookings);
        return "admin_dashboard";
    }

    @PostMapping("/admin/addTurf")
    public String addTurfUI(@RequestParam String turfName) {
        turfService.addTurf(turfName);
        return "redirect:/admin/dashboard";
    }
}
