package in.turff.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestParam;

import in.turff.model.Booking;
import in.turff.service.TurfService;

@Controller
public class availableController {
    @Autowired
    private TurfService turfService;

//    @PostMapping("/addTurf")
//    public String addTurf(@RequestParam String turfName) {
//        turfService.addTurf(turfName);
//        return "Turf added successfully";
//    }
//    @GetMapping("/home")
//    public String showHome(Model model) {
//        // Add any model attributes if needed
//        return "index";
//    }
//    
    @GetMapping("/available/{turfId}")
    public List<Booking> getBookingsForTurf(@PathVariable Long turfId, @RequestParam LocalDate bookingDate) {
        return turfService.getBookingsForTurfOnDate(turfId, bookingDate);
    }
    
    @GetMapping("/available")
    public String showAdminDashboard(Model model) {
        // Retrieve bookings for each turf
        List<Booking> bookings = turfService.getAllBookings();
        model.addAttribute("bookings", bookings);
        return "available";
    }

//    @PostMapping("/admin/addTurf")
//    public String addTurfUI(@RequestParam String turfName) {
//        turfService.addTurf(turfName);
//        return "redirect:/admin/dashboard";
//    }
}