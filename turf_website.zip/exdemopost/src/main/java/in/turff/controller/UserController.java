
package in.turff.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import in.turff.model.Booking;
import in.turff.model.UserLoginRequest;
import in.turff.model.UserRegistrationRequest;
import in.turff.service.TurfService;
import in.turff.service.UserService;

@Controller
public class UserController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private TurfService turfService;

    private static String username_cs;

    @GetMapping("/login")
    public String showLoginPage(Model model) {
        model.addAttribute("userLoginRequest", new UserLoginRequest());
        return "login";
    }
//    @GetMapping("/home")
//    public String showHome(Model model) {
//        // Add any model attributes if needed
//        return "index";
//    }
    
    

    @PostMapping("/login")
    public String login(UserLoginRequest request, Model model) {
        String username = request.getUsername();
        String password = request.getPassword();
        username_cs = username;

        if (userService.authenticateUser(username, password)) {
            if ("admin".equals(username)) {
                return "redirect:/admin/dashboard";
            } else {
                return "redirect:/user/dashboard";
            }
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login"; // Return to login page with error message
        }
    }

    @PostMapping("/register")
    public String register(UserRegistrationRequest request, Model model) {
        String username = request.getUsername();
        String password = request.getPassword();

        if (userService.isUserExists(username)) {
            model.addAttribute("error", "Username already exists");
            return "register"; // Return to registration page with error message
        } else {
            userService.registerUser(username, password);
            model.addAttribute("message", "Registration successful");
            return "redirect:/login"; // Redirect to login page after successful registration
        }
    }

    @GetMapping("/register")
    public String showRegistrationPage(Model model) {
        model.addAttribute("userRegistrationRequest", new UserRegistrationRequest());
        return "register";
    }

    @GetMapping("/user/dashboard")
    public String showUserDashboard(Model model) {
        List<Booking> userBookings = turfService.getUserBookingsByUsername(username_cs);
        model.addAttribute("userBookings", userBookings);
        return "dashboard";
    }
}
