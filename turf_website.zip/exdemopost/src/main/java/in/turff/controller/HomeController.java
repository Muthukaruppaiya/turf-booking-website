package in.turff.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/index")
    public String showHomePage(Model model) {
        // Add any model attributes if needed
        return "index";
    }
//    @GetMapping("/home")
//    public String showHome(Model model) {
//        // Add any model attributes if needed
//        return "index";
//    }
//    
    @GetMapping("/contact")
    public String showcontact(Model model) {
        // Add any model attributes if needed
        return "contact";
    }
    @GetMapping("/about")
    public String showabout(Model model) {
        // Add any model attributes if needed
        return "about";
    }
    @GetMapping("/map")
    public String showmap(Model model) {
        // Add any model attributes if needed
        return "map";
    }
}
