package in.turff.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.turff.model.Booking;
import in.turff.model.Turf;
import in.turff.service.TurfService;

@Controller
public class TurfController {
    @Autowired
    private TurfService turfService;

    @GetMapping("/booking-page")
    public String showBookingPage(Model model) {
    	List<Turf> turfList = turfService.getAllTurfs(); // Assuming you have a method in your service to fetch all turfs
        model.addAttribute("turfs", turfList);
        return "booking-page";
    }
//    @GetMapping("/home")
//    public String showHome(Model model) {
//        // Add any model attributes if needed
//        return "index";
//    }
    
    

    
    @PostMapping("/bookTurf")
    public String bookTurf(@RequestParam("turfId") Long turfId,
                           @RequestParam("date") LocalDate date,
                           @RequestParam("time") LocalTime time,
                           @RequestParam("username")String username
                           ) {
        try {
            // Check if the turf is available for booking at the specified date and time
            if (turfService.isTurfAvailable(turfId, date, time)) {
                // Book the turf
                Booking booking = new Booking();
                booking.setTurfId(turfId);
                booking.setBookingDate(date);
                booking.setBookingTime(time);
                booking.setUserId(turfId);
                booking.setUserName(username);
                // You might also want to set other properties of the booking, such as the user ID
                turfService.bookTurf(booking);
                // Redirect to the user dashboard after successful booking
                return "redirect:/user/dashboard";
            } else {
                // The turf is not available at the specified date and time
                // You can redirect back to the user dashboard with an error message
                return "redirect:/user/dashboard?error=not_available";
            }
        } catch (Exception e) {
            // Handle booking error
            return "redirect:/user/dashboard?error=booking";
        }
    }
}


