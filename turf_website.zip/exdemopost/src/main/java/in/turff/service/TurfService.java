package in.turff.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.turff.dao.BookingRepository;
import in.turff.dao.TurfRepository;
import in.turff.exception.TurfBookingException;
import in.turff.model.Booking;
import in.turff.model.Turf;

@Service
public class TurfService {
	@Autowired
	private TurfRepository turfRepository;
	@Autowired
	private BookingRepository bookingRepository;

	public List<Turf> getAllTurfs() {
        return turfRepository.findAll();
    }
	
	public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

	public void bookTurf(Long turfId) {
		Turf turf = turfRepository.getById(turfId);
		if (turf != null && turf.isAvailable()) {
			turf.setAvailable(false);
			turfRepository.save(turf);
		} else {
			throw new TurfBookingException("Turf not available for booking");
		}
	}
	

	public boolean isTurfAvailable(Long turfId, LocalDate date, LocalTime time) {
        // Check if there are any existing bookings for the turf at the specified date and time
        List<Booking> existingBookings = bookingRepository.findByTurfIdAndBookingDateAndBookingTime(turfId, date, time);
        return existingBookings.isEmpty();
    }

    // Method to book a turf with the specified booking details
    public void bookTurf(Booking booking) {
        // Save the booking details to the database
        bookingRepository.save(booking);
    }
	public void addTurf(String turfName) {
		Turf newTurf = new Turf();
		newTurf.setName(turfName);
		newTurf.setAvailable(true);
		turfRepository.save(newTurf);
	}

	public List<Booking> getBookingsForTurfOnDate(Long turfId, LocalDate bookingDate) {
		return bookingRepository.findByTurfIdAndBookingDate(turfId, bookingDate);
	}
	public List<Booking> getUserBookingsByUsername(String username) {
		// TODO Auto-generated method stub
		return bookingRepository.findByUserName(username);
	}
	public List<Turf> findAll() {
		
		return turfRepository.findAll();
	}
}