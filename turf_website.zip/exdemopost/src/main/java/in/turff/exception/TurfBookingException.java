package in.turff.exception;

public class TurfBookingException extends RuntimeException {
    public TurfBookingException(String message) {
        super(message);
    }
}